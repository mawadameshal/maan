<style>
    table, th, td {
        border: 1px solid black;
    }
</style>
<table style="padding: 10px;border: 1px solid black;border-collapse: collapse;" border="1">
    <thead>
    <tr>
        <th colspan="12" style="text-align: center;vertical-align:center;background-color: #a9d08e; height: 30px;padding: 10px;border: 1px solid black;border-collapse: collapse;">المعلومات الأساسية:</th>
        <th colspan="22" style="text-align: center;vertical-align:center;background-color: #9bc2e6; height: 30px;padding: 10px;border: 1px solid black;border-collapse: collapse;">تفاصيل الاقتراح/الشكوى: </th>
        <th colspan="4" style="text-align: center;vertical-align:center;background-color: #a9d08e; height: 30px;padding: 10px;border: 1px solid black;border-collapse: collapse;">الردود والمتابعات: </th>
        <th colspan="5" style="text-align: center;vertical-align:center;background-color: #9bc2e6; height: 30px;padding: 10px;border: 1px solid black;border-collapse: collapse;">التغذية الراجعة: </th>
        <th colspan="2" style="text-align: center;vertical-align:center;background-color: #a9d08e; height: 30px;padding: 10px;border: 1px solid black;border-collapse: collapse;">متابعة الرد في حال عدم رضا مقدم الاقتراح/ الشكوى عن الرد الذي تلقاه </th>


    </tr>
    <tr>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">الرقم المرجعي</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">الاسم الرباعي</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">رقم الهوية</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">المحافظة</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">المنطقة</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">العنوان</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">رقم التواصل (1)</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">رقم التواصل (2)</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">فئة مقدم الاقتراح/الشكوى</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">اسم المشروع</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">حالة المشروع</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">رقم طلب المشروع</th>

        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">قناة الاستقبال</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">مكان تواجد الصندوق</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">تاريخ فتح الصندوق</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">رقم اجتماع فتح الصندوق</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">نوع زيارة المتابعة</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">اسم مسجل الاقتراح/الشكوى</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">اسم المستخدم ومستواه الإداري</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">تاريخ تقديم الاقتراح/الشكوى</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">تاريخ تسجيل الاقتراح/الشكوى</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">التصنيف</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">فئة الاقتراح/ الشكوى</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">موضوع الاقتراح/ الشكوى</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">محتوى الاقتراح/ الشكوى</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">الجهة المختصة بالدراسة والمعالجة</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">هل  الاقتراح/الشكوى بحاجة لاستيضاح</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">هل تم الاستيضاح عن المعلومات المطلوبة</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">سبب عدم الاستيضاح</th>
        <th style="text-align: center;vertical-align:center;background-color: #9bc2e6;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" colspan="3">نتائج استيضاح الاقتراح/الشكوى</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">التصنيف بناءً على الإجراءات المطلوبة</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">طبيعة الإجراءات المطولة المطلوبة للرد</th>

        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">حالة الرد</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">تفاصيل الرد</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">تاريخ تسجيل الرد</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">الجهة مسؤولة عن تبليغ الرد (موظف اتصال)</th>

        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">حالة تبليغ  الرد</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">سبب عدم تبيلغ الرد</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">تاريخ تبيلغ الرد</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">التغذية الراجعة</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">سبب عدم الرضا عن الرد</th>

        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">الجهة الإدارية المسؤولة عن متابعة أداء الجهات المختصة في معالجة الاقتراح/الشكوى</th>
        <th style="text-align: center;vertical-align:center;background-color: #c6e0b4;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;" rowspan="2">هل بحاجة لإعادة دراسة أو معالجة</th>

    </tr>
    <tr>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height:20px;padding: 10px;border: 1px solid black;border-collapse: collapse;">إعادة صياغة محتوى الاقتراح/ الشكوى بناءً على الاستيضاح</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;">فئة الاقتراح/ الشكوى</th>
        <th style="text-align: center;vertical-align:center;background-color: #bdd7ee;height: 20px;padding: 10px;border: 1px solid black;border-collapse: collapse;">الجهة المختصة بالدراسة والمعالجة</th>
    </tr>
    </thead>
    <tbody>

    @foreach($items as $item)
        <tr>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->id }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->first_name .' '.$item->father_name .' '.$item->grandfather_name.' '.$item->last_name }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->id_number }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->governorate }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->city }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->street }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->mobile }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->mobile2 }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{$item->project->id == 1 ? 'غير مستفيد' : ' مستفيد' }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{$item->project->name}}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{$item->project->end_date <= now() ?  'منتهي' : 'مستمر'}}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ '00970'.$item->id }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->senmmes }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;color: red;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;color: red;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;color: red;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;color: red;"></td>

            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->account_id }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->employee_name }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->datee }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->created_at }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->ammes }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->nammes }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->title }}</td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;">{{ $item->content }}</td>

            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
            <td style="padding: 10px;border: 1px solid black;border-collapse: collapse;"></td>
        </tr>
    @endforeach
    </tbody>
</table>

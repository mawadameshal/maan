@extends("layouts._account_layout")

@section("title", "لا يوجد صلاحية")


@section("content")
<div class="alert alert-danger">عذرا لا تملك صلاحية على الرابط المطلوب</div>
@endsection
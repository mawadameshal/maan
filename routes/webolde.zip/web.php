<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    $itemco=\App\Company::all()->first();
    return view('welcome',compact('itemco'));
});

///account/company/2/edit noaccses
Route::get('/noaccses',function (){
    $itemco=\App\Company::all()->first();
    return view('citizen.noaccses',compact('itemco'));
});
////منع البوست
Route::get('/account/login',function (){$itemco=\App\Company::all()->first();return view('welcome',compact('itemco'));});
Route::get('/account/restpassord',function (){$itemco=\App\Company::all()->first();return view('welcome',compact('itemco'));});
Route::get('/account/home/change-password-post',function (){$itemco=\App\Company::all()->first();return view('welcome',compact('itemco'));});
Route::get('/account/account/profileup/{id}',function (){$itemco=\App\Company::all()->first();return view('welcome',compact('itemco'));});
Route::get('/account/account/permission-post/{id}',function (){$itemco=\App\Company::all()->first();return view('welcome',compact('itemco'));});
Route::get('/account/account/select-project-post/{id}',function (){$itemco=\App\Company::all()->first();return view('welcome',compact('itemco'));});
Route::get('/account/project/importcitizentoproject/{id}',function (){$itemco=\App\Company::all()->first();return view('welcome',compact('itemco'));});
Route::get('/account/citizen/importcitizen',function (){$itemco=\App\Company::all()->first();return view('welcome',compact('itemco'));});
Route::get('/account/citizen/select-project-post/{id}',function (){$itemco=\App\Company::all()->first();return view('welcome',compact('itemco'));});
Route::get('/account/circle/select-category-post/{id}',function (){$itemco=\App\Company::all()->first(); return view('welcome',compact('itemco')); });
Route::get('/account/form/addreplay/{id}',function (){$itemco=\App\Company::all()->first(); return view('welcome',compact('itemco')); });
Route::get('/citizen/savenew',function (){$itemco=\App\Company::all()->first(); return view('welcome',compact('itemco')); });
Route::get('/citizen/saveolde/{id}',function (){$itemco=\App\Company::all()->first(); return view('welcome',compact('itemco')); });
Route::get('/forms/formsavenew',function (){$itemco=\App\Company::all()->first(); return view('welcome',compact('itemco')); });
Route::get('/forms/formsaveolde/{id}',function (){$itemco=\App\Company::all()->first(); return view('welcome',compact('itemco')); });
Route::get('/forms/addfollow',function (){$itemco=\App\Company::all()->first(); return view('welcome',compact('itemco')); });
Route::get('/forms/addevaluate',function (){$itemco=\App\Company::all()->first(); return view('welcome',compact('itemco')); });
//////
Route::get('/account','Account\HomeController@dashboard');
Route::get('/account/home/dashboard','Account\HomeController@dashboard');
Route::get('/account/home/noaccess','Account\HomeController@noaccess');
Route::get('/account/home/change-password','Account\HomeController@changePassword');
Route::post('/account/home/change-password-post','Account\HomeController@changePasswordPost');
Route::resource("/account/company","Account\CompanyController");
Route::resource("/account/message","Citizen\MessageController");
Route::get('/account/message/delete/{id}','Citizen\MessageController@destroy');
Route::get('/back','Account\HomeController@backup');

Route::post('/back','Account\HomeController@backup');
///لوجين ونسيت
///
Route::post('/account/login','AuthController@ajaxlogin');
Route::post('/account/restpassord','AuthRestController@sendResetLinkEmail');

//ادارة الحسابات
//
Route::get('/account/account/permission/{id}','Account\AccountController@permission');
Route::get('/account/account/profile/{id}','Account\AccountController@profile');
Route::patch('/account/account/profileup/{id}','Account\AccountController@profileup');
Route::resource("/account/account","Account\AccountController");
Route::get('/account/account/delete/{id}','Account\AccountController@destroy');
Route::post('/account/account/permission-post/{id}','Account\AccountController@permissionPost');
Route::get('/account/account/select-project/{id}','Account\AccountController@selectproject');
Route::post('/account/account/select-project-post/{id}','Account\AccountController@selectprojectPost');
Route::get('/account/account/formtoaccount/{id}','Account\AccountController@formtoaccount');
Route::get('/account/account/forminaccount/{id}','Account\AccountController@forminaccount');
//ادارة المشاريع
Route::get('/account/project/backupall','Account\ProjectController@backupall');
Route::get('/account/project/printall','Account\ProjectController@printall');
Route::post('/account/project/importcitizentoproject/{id}','Account\ProjectController@import');
Route::resource("/account/project","Account\ProjectController");
Route::get('/account/project/delete/{id}','Account\ProjectController@destroy');
Route::get('/account/project/printshow/{id}','Account\ProjectController@printshow');
Route::get('/account/project/active/{id}','Account\ProjectController@active');
Route::get('/account/project/citizeninproject/{id}','Account\ProjectController@citizeninproject');
Route::get('/account/project/accountinproject/{id}','Account\ProjectController@accountinproject');
Route::get('/account/project/forminproject/{id}','Account\ProjectController@forminproject');

//ادارة المواطنين
Route::post('/account/citizen/importcitizen','Account\CitizenController@import');
Route::get('/account/citizen/backupall','Account\CitizenController@backupall');
Route::get('/account/citizen/backupalltoproject/{id}','Account\CitizenController@backupalltoproject');
Route::resource("/account/citizen","Account\CitizenController");
Route::get('/account/citizen/delete/{id}','Account\CitizenController@destroy');
Route::get('/account/citizen/select-project/{id}','Account\CitizenController@selectproject');
Route::post('/account/citizen/select-project-post/{id}','Account\CitizenController@selectprojectPost');
Route::get('/account/citizen/accept/{id}','Account\CitizenController@accept');
Route::get('/account/citizen/formincitizen/{id}','Account\CitizenController@formincitizen');

//ادارة الفئات
Route::resource("/account/category","Account\CategoryController");
Route::get('/account/category/delete/{id}','Account\CategoryController@destroy');

//ادارة الدوائر
Route::resource("/account/circle","Account\CircleController");
Route::get('/account/circle/delete/{id}','Account\CircleController@destroy');
Route::get('/account/circle/select-category/{id}','Account\CircleController@selectcategory');
Route::post('/account/circle/select-category-post/{id}','Account\CircleController@selectcategoryPost');

//ادارة النماذج
Route::get('/account/form/printall','Account\FormController@printall');
Route::get('/account/form/backupall','Account\FormController@backupall');
Route::get('/account/form/delete/{id}','Account\FormController@destroy');
Route::get('/account/form/printalltoproject/{id}','Account\FormController@printalltoproject');
Route::get('/account/form/printalltoaccount/{id}','Account\FormController@printalltoaccount');
Route::get('/account/form/printalltocitizen/{id}','Account\FormController@printalltocitizen');
Route::get('/account/form/backupalltoproject/{id}','Account\FormController@backupalltoproject');
Route::get('/account/form/backupalltoaccount/{id}','Account\FormController@backupalltoaccount');
Route::get('/account/form/backupalltocitizen/{id}','Account\FormController@backupalltocitizen');
Route::resource("/account/form","Account\FormController");
Route::get('/account/form/delete/{id}','Account\FormController@destroy');
Route::get('/account/form/printshow/{id}','Account\FormController@printshow');
Route::post('/account/form/addreplay/{id}','Account\FormController@addreplay');
Route::get('/account/form/terminateform/{id}','Account\FormController@terminateform');
Route::get('/account/form/allowform/{id}','Account\FormController@allowform');
Route::put('/account/form/change-category/{id}','Account\FormController@changecategory');
//عرض النموذج وردوده ومتابعته
Route::get('/citizen/form/show/{ido}/{id}','Citizen\FormController@show');
Route::get('/citizen/form/addfollw/{id}','Citizen\FormController@addfollw');
/////////////////المواطن
//اضافة النماذج
Route::get('/citizen/form/searchbeforadd/{type}','Citizen\CitizenController@searchbyidnum');
Route::get('/citizen/getproject','Citizen\CitizenController@gethisproject');
Route::get('/citizen/editorcreatcitizen','Citizen\CitizenController@editorcreatcitizen');
Route::post('/citizen/savenew','Citizen\CitizenController@store');
Route::patch('/citizen/saveolde/{id}','Citizen\CitizenController@update');
Route::get('/form/addform/{type}/{citzen_id}/{project_id}','Citizen\CitizenController@addform');
Route::post('/forms/formsavenew','Citizen\CitizenController@formstore');
Route::get('/form/confirm/{id}','Citizen\CitizenController@confirmform');
//Route::get('/form/editform/{id}','Citizen\CitizenController@editform');
Route::patch('/forms/formsaveolde/{id}','Citizen\CitizenController@formupdate');
Route::get('/citizen/form/delayform/{id}','Citizen\CitizenController@delayform');
//متابعة النماذج
Route::get('/citizen/form/search','Citizen\CitizenController@searchbyidnumorform');
Route::get('/citizen/form/getforms','Citizen\CitizenController@getforms');
Route::post('/forms/addfollow','Citizen\CitizenController@addfollow');
Route::post('/forms/addevaluate','Citizen\CitizenController@addevaluate');
    //Auth::routes();
/////////////////////////////////////////////////////////////////////////////////////////////////////
// Authentication Routes...
Route::get('login', function () {
    $itemco=\App\Company::all()->first();
    return view('welcome',compact('itemco'));
})->name('login');

Route::get('logout', function () {
    $itemco=\App\Company::all()->first();
    return view('welcome',compact('itemco'));
});

Route::post('login', 'Auth\LoginController@login');
Route::middleware('auth')->post('logout', 'Auth\LoginController@logout')->name('logout');

// Registration Routes...
Route::get('register',  function () {
    $itemco=\App\Company::all()->first();
    return view('welcome',compact('itemco'));
})->name('register');
Route::post('register', 'Auth\RegisterController@register');

// Password Reset Routes...
Route::get('password/reset', function () {
    $itemco=\App\Company::all()->first();
    return view('welcome',compact('itemco'));
})->name('password.request');
Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
Route::post('password/reset', 'Auth\ResetPasswordController@reset');







<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Company;

class CreateAdminLinks extends Seeder
{

    /*
    You need to put SongsTableSeeder into file SongsTableSeeder.php in the same directory where you have your DatabaseSeeder.php file.

    And you need to run in your console:

    composer dump-autoload
    to generate new class map and then run:

    php artisan db:seed
    */

    public function run()
    {


    }
}
